#!/bin/bash

#Push to igagis repo for now
pod repo push igagis pugixml.podspec --use-libraries --verbose
