t = 0:2;
first = mod(t.^3+2.*t+1,3)
second = mod(t.^3+t.^2+t+2,3)