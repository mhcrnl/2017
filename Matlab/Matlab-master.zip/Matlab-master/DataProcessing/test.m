clear
clc
cl = data;
c1 = data;
c2 = data
cl = cl.merge(c1);
