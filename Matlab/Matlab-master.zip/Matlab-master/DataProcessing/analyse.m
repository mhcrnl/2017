function  true = analyse(path)
%ANALYSE This function is used by scraper.m. This file is to edit for the
%user purposes and should countain 2 parts: First it should check if a folder is
%to be analysed and second, if interesting, it should do the actual
%analysation.

%% checking if folder is to be analysed

%% processing if neccesairly


end

