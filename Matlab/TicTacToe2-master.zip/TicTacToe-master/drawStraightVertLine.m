function drawStraightVertLine(boxBegin,boxEnd,box)

plot([box.xMin(boxBegin)+1.5 box.xMin(boxBegin)+1.5],[box.yMax(boxBegin)-0.5 box.yMin(boxEnd)+0.5],'black','LineWidth',2);

end