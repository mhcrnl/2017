function num = numRows(a)

num = size(a,1);

end
