function num = numCols(a)

num = size(a,2);

end