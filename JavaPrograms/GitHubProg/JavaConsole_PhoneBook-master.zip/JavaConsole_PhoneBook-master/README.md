### Project: JavaConsole_PhoneBook

This is the structure of project:
1. JavaConsole_PhoneBook.java > main
2. Contact.java
3.PersistentContact.java
4.Controller.java

![screenshot](https://github.com/mhcrnl/JavaConsole_PhoneBook/blob/master/ScreenShot/Screenshot%20from%202016-05-03%2013:56:42.png)