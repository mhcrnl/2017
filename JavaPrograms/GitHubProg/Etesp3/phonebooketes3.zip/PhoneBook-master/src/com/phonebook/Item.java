package phone;

/**
 * (c) Ermias B. Tesfamariam 2010
 *
 * @author Ermias
 * @since 09:01:39 - 21.03.2010
 */
//An interface with Accessor methods to retrieve a name, address and number of a contact
public interface Item {
	public String getName();
	public String getAddress();
	public String getPhoneNumber();

}
