/**
 * Created by homic1de on 28.10.2014.
 */
public class User {
    public String name;
    public String number;
    public int age;

    public User(String name, String number, int age) {
        this.name = name;
        this.number = number;
        this.age = age;
    }
}
