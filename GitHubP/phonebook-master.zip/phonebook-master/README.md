# Telefonni seznam

{
  jmeno
  prijmeni - F
  adresa
  tel      - F
}

1. Find
2. Pridavani novych zaznamu (Add)
3. Smazani zaznamu (Del)
4. Ulozeni

Muze byt vic jmen se stejnym prijmenim, nemuze byt vic telefonnich cisel

- Mazani podle prijmeni
  - Pokud jich je vic tak je vypsat a dat na vyber ktery z nich mame
    smazat

