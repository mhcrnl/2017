#include <iostream>
#include "TicTacToe.h"
using namespace std;

int main()
{
    cout << "Hello world!" << endl;
    init();
    showBoard();
    return 0;
}
