#ifndef TICTACTOE_H_INCLUDED
#define TICTACTOE_H_INCLUDED

void init();
bool validate();
void clearScreen();
void showBoard();
bool gameOver(); //implement this method




#endif // TICTACTOE_H_INCLUDED
