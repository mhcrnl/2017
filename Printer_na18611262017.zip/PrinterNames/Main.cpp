#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <memory>
#include <Windows.h>

#pragma comment(lib, "Winspool.lib")

typedef std::vector<std::string> StringVector;

bool getPrinterNames(StringVector& names)
{
  DWORD dwSize, dwPrinters;

  ::EnumPrintersA(PRINTER_ENUM_LOCAL, 0, 5, 0, 0, &dwSize, &dwPrinters);
  //BYTE *pBuffer = new BYTE[dwSize];
  std::unique_ptr<BYTE[]> pBuffer(new BYTE[dwSize]);
  ::EnumPrintersA(PRINTER_ENUM_LOCAL, 0, 5, pBuffer.get(), dwSize, &dwSize, &dwPrinters);
  if (dwPrinters != 0)
  {
    PRINTER_INFO_5A* pPrnInfo = (PRINTER_INFO_5A*) pBuffer.get();

    for (UINT i = 0; i < dwPrinters; i++)
    {
      names.push_back(std::string(pPrnInfo->pPrinterName));
      pPrnInfo++;
    }
    //delete [] pBuffer;
    return true;
  }
  //delete [] pBuffer;
  return false;
}


int main()
{
  StringVector names;

  std::cout << "Printer info\n";
  std::cout << "============\n";
  
  if (getPrinterNames(names))
  {
    if(!names.empty())
    {
      std::cout << "Installed printers:\n";
      for_each(names.begin(), names.end(), [] (const std::string& s)
      {
        std::cout << "\n-> " << s;
      });
    }
    else
    {
      std::cout << "\nNo printers installed.";
    }
  }
  else
  {
    std::cout << "Win Error: " << GetLastError() << "\n\n";
  }
  system("pause");
  return 0;
}