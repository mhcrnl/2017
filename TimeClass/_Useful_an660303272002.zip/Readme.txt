Description of files
====================
timeclass.dsw - project file

timeclass.dsp - workspace file

time.h - A file which contains the class i made which accesses the system time and date and
		includes a stopwatch

ex.cpp - A demonstration program which uses most of the aspects of time.h

string.h - Declaration file for a string class

string.cpp - Implementation file for a string class

Description of Program
======================
This declares a class in time.h which contains functions which return string values of the current time, using the string class included with this program, and a stopwatch.
Those functions and the stopwatch are demonstrated.
Not demonstrated in the example program is the use of the m_time struct in the class which contains various things like month, year, hour min, sec, etc.
Any questions or comments feel free to contact me at mattg2k4@yahoo.com