Title: _Useful and ez time and date class
Description: This declares an easy to use time and date class with built in functions to generate string outputs of time and dates. It has a built in stopwatch, which doesnt work w/ borland and should be commented out. It has an example program which demonstrates the basic use of the class. (again, make sure to comment out the stopwatch section for borland users, it DOES work with MVC++)
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=3598&lngWId=3

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
