// Copyright (C) 2007  Davis E. King (davis@dlib.net)
// License: Boost Software License   See LICENSE.txt for the full license.
#ifndef DLIB_TIMEOUt_
#define DLIB_TIMEOUt_

#include "timeout/timeout.h"

#endif // DLIB_TIMEOUt_


